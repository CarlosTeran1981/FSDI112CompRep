

function getData(){
    $.ajax({
        url: '/api/movies',
        type: "GET",
        success: function(res){
            var movies = res.objects;
            for (var i = 0; i < movies.length; i++) {
                displayMovie(movies[i]);
            }

        },
        error: function(details) {
            console.log("Error on get req", details);
        }
    });
}

function postCODE() {
    var newG = {
        name: "This is the new one"
    };

    $.ajax({
      url: '/api/genres',
      type: "POST",
      contentType: 'application/json',
      data: JSON.stringify(newG),
      success: function (res) {
          console.log("Error on post req", details);
      }
    });
}

function displayMovie(movies){
    console.log(movies);

    var container = $(".cat-container");

    var li = `<li><img src="${movies.image}"> ${movies.title}</li>`;
    container.append(li);
 }



function init() {
  console.log("Hello catalog page");

  getData();

}





window.onload = init();